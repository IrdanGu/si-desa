<?php

use App\Http\Controllers\AgendaController;
use App\Http\Controllers\AgendaKarangtarunaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\strukturdesaController;
use App\Http\Controllers\BeritaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GaleryController;
use App\Http\Controllers\Navbar_Controller;
use App\Http\Controllers\PendudukController;
use App\Http\Controllers\PotensiDesaController;
use App\Http\Controllers\Surat_KeteranganUsahaController;
use App\Http\Controllers\SuratController;
use App\Http\Controllers\TampilanuserController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Auth;

Route::get('/kontak', function () {
    return view('frontend/kontak', [
       "title" => "Kontak kami"
    ]);
});

Route::get('/panduan', function () {
    return view('frontend/panduan ', [
       "title" => "Panduan kami"
    ]);
});


Route::get('/visimisi', function () {
    return view('frontend/visimisi', [
        "title" => "Visi dan Misi"
    ]);
});

Route::get('/potensidesa', function () {
    return view('frontend/potensidesa', [
        "title" => "potensidesa"
    ]);
});

Route::get('/login', function () {
    return view('auth/login', [
        "title" => "login"
    ]);
});

Route::get('/dashboard', function () {
    return view('dashboard', [
        "title" => "dashboard"
    ]);
});




// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

  //umport data peduduk


  Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');


  Auth::routes(['register' => false]);



  Route::group([
    'prefix' => 'agenda_karangtaruna'
], function(){
    Route::get('index', [AgendaKarangtarunaController::class, 'index'])->name('agenda_karangtarunaindex');
    Route::get('create', [AgendaKarangtarunaController::class, 'create'])->name('agenda_karangtarunacreate');
    Route::post('store', [AgendaKarangtarunaController::class, 'store'])->name('agenda_karangtarunastore');
    Route::get('edit/{judul}', [AgendaKarangtarunaController::class, 'edit'])->name('agenda_karangtarunaedit');
    Route::put('store/{judul}', [AgendaKarangtarunaController::class, 'update'])->name('agenda_karangtarunaupdate');
    Route::delete('delete/{judul}', [AgendaKarangtarunaController::class, 'destroy'])->name('agenda_karangtarunadelete');

});


Route::group([
    'prefix' => 'berita'
], function() {
    Route::get('index', [BeritaController::class, 'index'])->name('beritaindex');
    Route::get('create', [BeritaController::class, 'create'])->name('beritacreate');
    Route::post('store', [BeritaController::class, 'store'])->name('beritastore');
    Route::get('edit/{slug}', [BeritaController::class, 'edit'])->name('beritaedit');
    Route::put('store/{slug}', [BeritaController::class, 'update'])->name('beritaupdate');
    Route::delete('delete/{slug}', [BeritaController::class, 'destroy'])->name('beritadelete');

});







// route untuk surat  di halaman user
Route::get('surat', [TampilanuserController::class, 'surat'])->name('surat');
Route::post('store', [TampilanuserController::class, 'store'])->name('suratsimpan');
Route::put('store/update/{id}', [TampilanuserController::class, 'update'])->name('surattupdate');
Route::put('store/updateSKU/{id}', [TampilanuserController::class, 'updateSKU'])->name('suratupdateSKU');



//navbar admin
Route::get('/navbar-data', [Navbar_Controller::class, 'getSuratCount'])->name('navbar.data');
Route::get('/navbar', [Navbar_Controller::class, 'navbar'])->name('navbar');
Route::post('/notification/read', [Navbar_Controller::class, 'markNotificationAsRead'])->name('notification.read');


// ini route untuk halaman user frontend
Route::get('/', [TampilanuserController::class, 'index'])->name('indexuser');
Route::get('berita/{slug}', [TampilanuserController::class, 'detail_berita'])->name('berita_detail');
Route::get('/userberita', [TampilanuserController::class, 'main_berita'])->name('berita_main');
Route::get('/aparatur', [TampilanuserController::class, 'aparatur'])->name('aparatur');
Route::get('/useragenda', [TampilanuserController::class, 'main_agenda'])->name('agenda_main');
// Route::get('agenda/{judul}', [TampilanuserController::class, 'detail_agenda'])->name('agenda_detail');
Route::get('/useragenda_karangtaruna', [TampilanuserController::class, 'main_agenda_karangtaruna'])->name('agenda_karangtaruna_main');
Route::get('agenda_karangtaruna/{judul}', [TampilanuserController::class, 'detail_agenda_karangtaruna'])->name('agenda_karangtaruna_detail');
Route::get('/galery', [TampilanuserController::class, 'main_galery'])->name('galery_main');
Route::get('/potensidesa', [TampilanuserController::class, 'potensi_desa'])->name('potensi_desa');






//midleware login admin dan karangtaruna

//admin
Route::group(['middleware' => 'admin'], function(){

    // halaman dashboard admin
    // Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');







    Route::group([
        'prefix' => 'dataaparatur'
    ], function() {
        Route::get('index', [StrukturDesaController::class, 'index'])->name('aparaturindex');
        Route::get('create', [StrukturDesaController::class, 'create'])->name('aparaturcreate');
        Route::post('store', [StrukturDesaController::class, 'store'])->name('aparaturstore');
        Route::get('edit/{id}', [StrukturDesaController::class, 'edit'])->name('aparaturedit');
        Route::put('store/{id}', [StrukturDesaController::class, 'update'])->name('aparaturupdate');
        Route::delete('delete/{id}', [StrukturDesaController::class, 'destroy'])->name('aparaturdelete');



    });

    Route::group([
        'prefix' => 'penduduk'
    ], function() {
        Route::get('index', [PendudukController::class, 'index'])->name('pendudukindex');
        Route::get('create', [PendudukController::class, 'create'])->name('pendudukcreate');
        Route::post('store', [PendudukController::class, 'store'])->name('pendudukstore');
        Route::get('edit/{id}', [PendudukController::class, 'edit'])->name('pendudukedit');
        Route::put('store/{id}', [PendudukController::class, 'update'])->name('pendudukupdate');
        Route::delete('delete/{id}', [PendudukController::class, 'destroy'])->name('pendudukdelete');
        Route::get('detail/{id}', [PendudukController::class, 'show'])->name('pendudukshow');
        Route::get('export_excel', [PendudukController::class, 'export_excel'])->name('pendudukexport');
        Route::post('import_excel', [PendudukController::class, 'import_excel'])->name('pendudukimport');
        Route::get('export_pdf', [PendudukController::class, 'export_pdf'])->name('pendudukexportpdf');
    });

    // ajax
    Route::get('penduduk/{nik}', [PendudukController::class, 'ajax']);

    Route::group([
        'prefix' => 'berita'
    ], function() {
        Route::get('index', [BeritaController::class, 'index'])->name('beritaindex');
        Route::get('create', [BeritaController::class, 'create'])->name('beritacreate');
        Route::post('store', [BeritaController::class, 'store'])->name('beritastore');
        Route::get('edit/{slug}', [BeritaController::class, 'edit'])->name('beritaedit');
        Route::put('store/{slug}', [BeritaController::class, 'update'])->name('beritaupdate');
        Route::delete('delete/{slug}', [BeritaController::class, 'destroy'])->name('beritadelete');

    });











    Route::group([
        'prefix' => 'agenda'
    ], function(){
        Route::get('index', [AgendaController::class, 'index'])->name('agendaindex');
        Route::get('create', [AgendaController::class, 'create'])->name('agendacreate');
        Route::post('store', [AgendaController::class, 'store'])->name('agendastore');
        Route::get('edit/{judul}', [AgendaController::class, 'edit'])->name('agendaedit');
        Route::put('store/{judul}', [AgendaController::class, 'update'])->name('agendaupdate');
        Route::delete('delete/{judul}', [AgendaController::class, 'destroy'])->name('agendadelete');

    });

    Route::group([
        'prefix' => 'agenda_karangtaruna'
    ], function(){
        Route::get('index', [AgendaKarangtarunaController::class, 'index'])->name('agenda_karangtarunaindex');
        Route::get('create', [AgendaKarangtarunaController::class, 'create'])->name('agenda_karangtarunacreate');
        Route::post('store', [AgendaKarangtarunaController::class, 'store'])->name('agenda_karangtarunastore');
        Route::get('edit/{judul}', [AgendaKarangtarunaController::class, 'edit'])->name('agenda_karangtarunaedit');
        Route::put('store/{judul}', [AgendaKarangtarunaController::class, 'update'])->name('agenda_karangtarunaupdate');
        Route::delete('delete/{judul}', [AgendaKarangtarunaController::class, 'destroy'])->name('agenda_karangtarunadelete');

    });


    Route::group([
        'prefix' => 'potensi_desa'
    ], function(){
        Route::get('index', [PotensiDesaController::class, 'index'])->name('potensi_desaindex');
        Route::get('create', [PotensiDesaController::class, 'create'])->name('potensi_desacreate');
        Route::post('store', [PotensiDesaController::class, 'store'])->name('potensi_desastore');
        Route::get('edit/{judul}', [PotensiDesaController::class, 'edit'])->name('potensi_desaedit');
        Route::put('store/{judul}', [PotensiDesaController::class, 'update'])->name('potensi_desaupdate');
        Route::delete('delete/{judul}', [PotensiDesaController::class, 'destroy'])->name('potensi_desadelete');

    });

    Route::group([
        'prefix' => 'galery'
    ], function() {
        Route::get('index', [GaleryController::class, 'index'])->name('galeryindex');
        Route::get('create', [GaleryController::class, 'create'])->name('galerycreate');
        Route::post('store', [GaleryController::class, 'store'])->name('galerystore');
        Route::get('edit/{nama}', [GaleryController::class, 'edit'])->name('galeryedit');
        Route::put('store/{nama}', [GaleryController::class, 'update'])->name('galeryupdate');
        Route::delete('delete/{nama}', [GaleryController::class, 'destroy'])->name('galerydelete');

    });

    //surat Keterangan Tidak Mampu

    Route::group([
        'prefix' => 'surat'
    ], function(){
        Route::get('index', [SuratController::class, 'index'])->name('suratindex');
        Route::get('create', [SuratController::class, 'create'])->name('suratcreate');
        Route::post('store', [SuratController::class, 'store'])->name('suratstore');
        Route::get('edit/{id}', [SuratController::class, 'edit'])->name('suratedit');
        Route::put('store/{id}', [SuratController::class, 'update'])->name('suratupdate');
        Route::delete('delete/{id}', [SuratController::class, 'destroy'])->name('suratdelete');
    });


    Route::group([
        'prefix' => 'user'
    ], function () {
        Route::get('index', [UserController::class, 'index'])->name('userindex');
        Route::get('create', [UserController::class, 'create'])->name('usercreate');
        Route::post('store', [UserController::class, 'store'])->name('userstore');

    });

    Route::group([
        'prefix' => 'surat_keteranganusaha'
    ], function(){
        Route::get('index', [Surat_KeteranganUsahaController::class, 'index'])->name('surat_keteranganusahaindex');

    });

//     // ini route untuk halaman user frontend
// Route::get('/', [TampilanuserController::class, 'index'])->name('indexuser');
// Route::get('berita/{slug}', [TampilanuserController::class, 'detail_berita'])->name('berita_detail');
// Route::get('/userberita', [TampilanuserController::class, 'main_berita'])->name('berita_main');
// Route::get('/aparatur', [TampilanuserController::class, 'aparatur'])->name('aparatur');
// Route::get('/useragenda', [TampilanuserController::class, 'main_agenda'])->name('agenda_main');
Route::get('agenda/{judul}', [TampilanuserController::class, 'detail_agenda'])->name('agenda_detail');
// Route::get('/useragenda_karangtaruna', [TampilanuserController::class, 'main_agenda_karangtaruna'])->name('agenda_karangtaruna_main');
// Route::get('agenda_karangtaruna/{judul}', [TampilanuserController::class, 'detail_agenda_karangtaruna'])->name('agenda_karangtaruna_detail');
// Route::get('/galery', [TampilanuserController::class, 'main_galery'])->name('galery_main');
// Route::get('/potensidesa', [TampilanuserController::class, 'potensi_desa'])->name('potensi_desa');





});


//karangtaruna
Route::group(['middleware' => 'checkuser'], function(){

    // Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::group([
        'prefix' => 'agenda_karangtaruna'
    ], function(){
        Route::get('index', [AgendaKarangtarunaController::class, 'index'])->name('agenda_karangtarunaindex');
        Route::get('create', [AgendaKarangtarunaController::class, 'create'])->name('agenda_karangtarunacreate');
        Route::post('store', [AgendaKarangtarunaController::class, 'store'])->name('agenda_karangtarunastore');
        Route::get('edit/{judul}', [AgendaKarangtarunaController::class, 'edit'])->name('agenda_karangtarunaedit');
        Route::put('store/{judul}', [AgendaKarangtarunaController::class, 'update'])->name('agenda_karangtarunaupdate');
        Route::delete('delete/{judul}', [AgendaKarangtarunaController::class, 'destroy'])->name('agenda_karangtarunadelete');

    });

    Route::group([
        'prefix' => 'berita'
    ], function() {
        Route::get('index', [BeritaController::class, 'index'])->name('beritaindex');
        Route::get('create', [BeritaController::class, 'create'])->name('beritacreate');
        Route::post('store', [BeritaController::class, 'store'])->name('beritastore');
        Route::get('edit/{slug}', [BeritaController::class, 'edit'])->name('beritaedit');
        Route::put('store/{slug}', [BeritaController::class, 'update'])->name('beritaupdate');
        Route::delete('delete/{slug}', [BeritaController::class, 'destroy'])->name('beritadelete');

    });



});



