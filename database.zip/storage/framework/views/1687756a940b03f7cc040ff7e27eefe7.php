<?php $__env->startSection('title'); ?>
    Detail Penduduk
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card ">
    <div class="card-header">
        <h3 class="card-title">Detail Penduduk</h3>
    </div>

    <div class="card-body">
    <pre>
    <b><p>No KK           : </b> <?php echo e($penduduk->no_kk); ?></p>
    <b><p>Alamat </b>         :  <b>Dusun : </b><?php echo e($penduduk->dusun); ?> | <b> RT :</b> <?php echo e($penduduk->rt); ?> | <b>RW :</b> <?php echo e($penduduk->rw); ?> | <b>Desa :</b> <?php echo e($penduduk->desa); ?> | <b>Kecamatan : </b> <a>Garawangi</a> </p>
    <b><p>Nama Lengkap    : </b> <?php echo e($penduduk->nama_lengkap); ?></p>
    <b><p>Tempat Lahir    : </b> <?php echo e($penduduk->tempat_lahir); ?></p>
    <b><p>Tanggal Lahir   : </b> <?php echo e(date('d-m-Y',strtotime($penduduk->tanggal_lahir))); ?></p>
    <b><p>Jenis Kelamin   : </b> <?php echo e($penduduk->jenis_kelamin); ?></p>
    <b><p>Pendidikan      : </b> <?php echo e($penduduk->pendidikan); ?></p>
    <b><p>Pekerjaan       : </b> <?php echo e($penduduk->pekerjaan); ?></p>
    <b><p>Status          : </b> <?php echo e($penduduk->status); ?></p>
    </div>
</pre>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/penduduk/detail.blade.php ENDPATH**/ ?>