<?php $__env->startSection('title'); ?>
    potensi_desa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="coba">
    <section id="main-container" class="main-container" >
       <div class="container ">
          <div class="row" >
             <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
                <?php $__currentLoopData = $potensi_desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $potensi_desas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post-content post-single">
                   <div class="post-media post-image image-angle">
                      <img  src="<?php echo e(asset('storage/' . $potensi_desas->gambar)); ?>" class="img-responsive " alt="">
                   </div>

                   <div class="post-body">
                      <div class="entry-header">
                         <h2 class="entry-title">
                           <?php echo e($potensi_desas->judul); ?>

                         </h2>
                      </div><!-- header end -->

                      <div class="entry-content">
                         <?php echo $potensi_desas->content; ?>

                      </div>
                   </div><!-- post-body end -->

                </div><!-- post content end -->
             </div><!-- Content Col end -->
          </div><!-- Main row end -->
       </div>
    </div>
</div>
</div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
   </div>
   <?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('constra/js/owl.carousel.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('constra_template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/frontend/potensidesa.blade.php ENDPATH**/ ?>