<?php $__env->startSection('title'); ?>
    main berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="mainberita" class="berita">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
            <H3 class="orange-text">Berita</H3>
            <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4">
                <img  src="<?php echo e(asset('storage/' . $beritas->gambar)); ?>" class="img-responsive " alt="">
                <div class="post-meta-berita">
                    <span class="post-author">
                       <i class="fa fa-user"></i><a href="#"> <?php echo e($beritas->user->level); ?></a>
                    </span>
                    |

                    <span class="post-meta-date"><i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($beritas['created_at'])->isoFormat('D MMMM, Y')); ?></span>
                 </div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($beritas->judul); ?></h5>
                    <?php echo e(Str::limit(strip_tags(html_entity_decode($beritas->content)), 150)); ?>

                <br>
                    <a href="<?php echo e(route('berita_detail',$beritas->slug)); ?>" class="btn btn-primary">Read More</a>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



            <!--/ Top info end -->

            <div class="col-md-4">
                <br>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    </button>
                </form>
                <br>
                <h4 class="orange-text">Popular <span class="font-weight-bold">Post</span></h4>
                <ul class="list-group">
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex align-items-start border-0 p-2 mb-10 ">
                            <div class="date-box-berita text-center mr-10 p-2">
                                <img  src="<?php echo e(asset('storage/' . $beritas->gambar)); ?>" class="card-img-main" alt="">

                            </div>

                            <div class="berita-text">
                                <span class="post-meta-date"><i class="fa fa-calendar"></i> <?php echo e(\Carbon\Carbon::parse($beritas->tanggal)->isoFormat('D MMMM, Y')); ?></span>
                                <br>
                                <a href="<?php echo e(route('agenda_detail', $beritas->judul)); ?>" class="judul-main"><?php echo e($beritas->judul); ?></a>
                                <p class="">by <?php echo e($beritas->user->name); ?></p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                  <!-- Galeri Foto -->
              <div class="iklan-galeri">
                <h4 class="orange-text-galery">
                    <i class="fas fa-camera icon"></i> <!-- Ganti ikon sesuai kebutuhan -->
                    Galeri Foto
                </h4>

              <div class="gallery-main">
                  <?php $__currentLoopData = $galery->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galerys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="gallery-item-main">
                          <img src="<?php echo e(asset('storage/' . $galerys->gambar)); ?>" alt="Gallery Image">
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          </div>
          </div>
            </div>


        </div>
    </div>
</div>
<br></br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('constra_template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/frontend/main_berita.blade.php ENDPATH**/ ?>