<div class="sidebar">
    <!-- Sidebar user (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
      <img src="<?php echo e(asset('storage/gambar/logoman.png')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <a href="#" class="d-block">(<?php echo e(Auth::user()->level); ?>) Desa Mancagar</a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
             <li class="nav-item">
              <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                  <i class="nav-icon fas fa-tachometer-alt"></i>
                  <p>
                 Dashboard
                  </p>
                </a>
              </li>
        <li class="nav-item">
          <a href="<?php echo e(route('aparaturindex')); ?>" class="nav-link">
              <i class="nav-icon fas fa-user-cog"></i>
              <p>
             Struktur Desa
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(route('pendudukindex')); ?>" class="nav-link">
                <i class="nav-icon fas fa-users"></i>
                <p>
                Penduduk
                </p>
              </a>
            </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('beritaindex')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-file-signature"></i>
                          <p>
                            Berita
                          </p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('galeryindex')); ?>" class="nav-link">
                          <i class="nav-icon fas fa-file-signature"></i>
                            <p>
                             Galery
                            </p>
                          </a>
                      </li>

                    <li class="nav-item">
                      <a href="<?php echo e(route('userindex')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-envelope-open-text"></i>
                          <p>
                            User
                          </p>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a href="<?php echo e(route('agendaindex')); ?>" class="nav-link">
                          <i class="nav-icon fas fa-file-signature"></i>
                            <p>
                              Agenda kegiatan
                            </p>
                          </a>
                      </li>

                      <li class="nav-item">
                        <a href="<?php echo e(route('agenda_karangtarunaindex')); ?>" class="nav-link">
                          <i class="nav-icon fas fa-file-signature"></i>
                            <p>
                              Agenda kegiatan Karangtaruna
                            </p>
                          </a>
                      </li>


                      <li class="nav-item">
                        <a href="<?php echo e(route('potensi_desaindex')); ?>" class="nav-link">
                          <i class="nav-icon fas fa-file-signature"></i>
                            <p>
                              Potensi Desa
                            </p>
                          </a>
                      </li>

                    <li class="nav-item">
                      <a href="<?php echo e(route('suratindex')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-mail-bulk"></i>
                          <p>
                            Surat Keterangan Tidak Mampu
                          </p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('surat_keteranganusahaindex')); ?>" class="nav-link">
                          <i class="nav-icon fas fa-mail-bulk"></i>
                            <p>
                              Surat Keterangan Usaha
                            </p>
                          </a>
                      </li>
          </ul>

    </nav>

  </div>
<?php /**PATH C:\laragon\www\sidesass\resources\views/adminlte/partial/sidebar.blade.php ENDPATH**/ ?>