<?php $__env->startSection('title'); ?>
    Data Berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Potensi Desa</h3>
    </div>
    <div class="card-header">
        <a class="btn btn-primary" href="<?php echo e(route('potensi_desacreate')); ?>">Tambah Data</a>
    </div>
    <div class="card-header">
      <form action="">
        <div class="row">
              <div class="col-md-7">
                <input value="<?php echo e(Request::get('keyword')); ?>" name="keyword" class="form-control"type="text" placeholder="Masukan Judul untuk pencarian.....">
              </div>
              <button type="submit" class="btn btn-primary"> <i class="fas fa-search" ></i> Cari </button>
        </div>
      </form>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table class="table table-bordered table-hover ">
        <thead class="table-secondary">
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>Slug</th>
            <th>Content</th>
            <th>Gambar</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $potensi_desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $potensi_desas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($no+1); ?></td>
              <td><?php echo e($potensi_desas->judul); ?></td>
              <td><?php echo e($potensi_desas->slug); ?></td>
              <td><?php echo e(Str::limit(strip_tags($potensi_desas->content), 100)); ?></td>
              <td><img src="<?php echo e(asset('storage/' . $potensi_desas->gambar)); ?>" width="48px"></td>
              <td>
              <a  href="<?php echo e(route('potensi_desaedit',$potensi_desas->slug)); ?>"><button style="padding-right:26px" type="submit"  class="btn btn-info"><i class="fas fa-edit"></i> Edit</button> </a>
                <form style="margin-top:2px;" action="<?php echo e(route('potensi_desadelete',$potensi_desas->slug)); ?>" method="post" >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button onclick="return confirm('Yakin Hapus Data Ini?')" class="btn  btn-danger" type="submit "><i class="fas fa-trash"></i> Hapus</button>
                </form>
              </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

      </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <ul class="pagination pagination-sm m-0 float-right">
        <?php echo e($potensi_desa->links()); ?>

      </ul>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/potensi_desa/index.blade.php ENDPATH**/ ?>