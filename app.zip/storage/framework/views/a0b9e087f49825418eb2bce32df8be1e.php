<?php $__env->startSection('title'); ?>
    Data Berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data Berita</h3>
    </div>
    <div class="card-header">
        <a class="btn btn-primary" href="<?php echo e(route('agendacreate')); ?>">Tambah Data</a>
    </div>
    <div class="card-header">
      <form action="">
        <div class="row">
              <div class="col-md-7">
                <input value="<?php echo e(Request::get('keyword')); ?>" name="keyword" class="form-control"type="text" placeholder="Masukan Judul untuk pencarian.....">
              </div>
              <button type="submit" class="btn btn-primary"> <i class="fas fa-search" ></i> Cari </button>
        </div>
      </form>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table class="table table-bordered table-hover ">
        <thead class="table-secondary">
          <tr>
            <th>No</th>
            <th>Judul</th>
            <th>tanggal</th>
            <th>jam</th>
            <th>acara</th>
            <th>tempat</th>
            <th>content</th>
            <th>pembuat</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $agendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($no+1); ?></td>
              <td><?php echo e($agendas->judul); ?></td>
              <td><?php echo e(date('d-m-Y',strtotime($agendas->tanggal))); ?></td>
              <td><?php echo e($agendas->jam); ?></td>
              <td><?php echo e($agendas->acara); ?></td>
              <td><?php echo e($agendas->tempat); ?></td>
              <td><?php echo e(Str::limit(strip_tags($agendas->content), 100)); ?></td>
              <td><?php echo e($agendas->user->level); ?></td>
              <td>
              <a  href="<?php echo e(route('agendaedit',$agendas->judul)); ?>"><button style="padding-right:26px" type="submit"  class="btn btn-info"><i class="fas fa-edit"></i> Edit</button> </a>
                <form style="margin-top:2px;" action="<?php echo e(route('agendadelete',$agendas->judul)); ?>" method="post" >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button onclick="return confirm('Yakin Hapus Data Ini?')" class="btn  btn-danger" type="submit "><i class="fas fa-trash"></i> Hapus</button>
                </form>
              </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

      </table>
    </div>
    <div class="d-flex justify-content-center">
        <?php echo e($agenda->links('pagination::bootstrap-4')); ?>

    </div>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/agenda/index.blade.php ENDPATH**/ ?>