<?php $__env->startSection('title'); ?>
    Penduduk
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-10 mx-auto">
<form role="form" action="<?php echo e(route(('pendudukupdate'),$penduduk->nik)); ?>" method="POST">
      <div class="card-body">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
          <div class="form-group">
              <label for="nik">Nomor KK</label>
              <input type="text" readonly name="no_kk" class="form-control <?php echo e($errors->first('no_kk') ? "is-invalid": ""); ?>" id="no_kk" value="<?php echo e($penduduk->no_kk); ?>">
          <div class="invalid-feedback">
            <?php echo e($errors->first('no_kk')); ?>

          </div>
        </div>
          <div class="form-group">
              <label for="nik">Nomor NIK</label>
              <input type="text" readonly name="nik" class="form-control <?php echo e($errors->first('nik') ? "is-invalid": ""); ?>" id="nik" value="<?php echo e($penduduk->nik); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('nik')); ?>

              </div>
            </div>
          <div class="form-group">
              <label for="nama_lengkap">Nama Lengkap</label>
              <input type="text" name="nama_lengkap" class="form-control <?php echo e($errors->first('nama_lengkap') ? "is-invalid": ""); ?> " id="nama_lengkap" value="<?php echo e($penduduk->nama_lengkap); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('nama_lengkap')); ?>

              </div>
            </div>

            <label for="level">Jenis Kelamin</label>
            <div class="form-group">
              <div class="form-check form-check-inline">
                <input  class="form-check-input" type="radio" <?php echo e($penduduk->jenis_kelamin == "laki" ? "checked" : ""); ?> name="jenis_kelamin" value="laki" >
                <label class="form-check-label">Laki-Laki</label>
              </div>
              <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" <?php echo e($penduduk->jenis_kelamin == "perempuan" ? "checked" : ""); ?> name="jenis_kelamin" value="perempuan">
                  <label class="form-check-label <?php echo e($errors->first('jenis_kelamin') ? "is-invalid": ""); ?>">Perempuan</label>
                  <div class="invalid-feedback">
                    &emsp;<?php echo e($errors->first('jenis_kelamin')); ?>

                  </div>
                </div>
            </div>

            <div class="form-group">
                <label for="hubungan">Hubungan</label>
                <input type="text" name="hubungan" class="form-control <?php echo e($errors->first('hubungan') ? "is-invalid": ""); ?> " id="hubungan" value="<?php echo e($penduduk->hubungan); ?>">
                <div class="invalid-feedback">
                  <?php echo e($errors->first('hubungan')); ?>

                </div>
              </div>

          <div class="form-group">
              <label for="tempat_lahir">Tempat Lahir</label>
              <input type="text" name="tempat_lahir" class="form-control <?php echo e($errors->first('tempat_lahir') ? "is-invalid": ""); ?> " id="tempat_lahir" value="<?php echo e($penduduk->tempat_lahir); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('tempat_lahir')); ?>

              </div>
            </div>
          <div class="form-group">
            <label>Tanggal lahir</label>
              <div class="input-group date" id="reservationdate" data-target-input="nearest">
                <div class="input-group-append" data-target="#reservationdate" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
                  <input name="tanggal_lahir" type="text" class="form-control datetimepicker-input <?php echo e($errors->first('tanggal_lahir') ? "is-invalid": ""); ?>  " data-target="#reservationdate" value="<?php echo e(date('d-m-Y',strtotime($penduduk->tanggal_lahir))); ?>">
                  <div class="invalid-feedback">
                    <?php echo e($errors->first('tanggal_lahir')); ?>

                  </div>
                </div>
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <input type="text" name="status" class="form-control <?php echo e($errors->first('status') ? "is-invalid": ""); ?>" id="status" value="<?php echo e($penduduk->status); ?>">
                <div class="invalid-feedback">
                  <?php echo e($errors->first('status')); ?>

                </div>
              </div>

            <div class="form-group">
              <label for="pendidikan">Pendidikan</label>
              <input type="text" name="pendidikan" class="form-control <?php echo e($errors->first('pendidikan') ? "is-invalid": ""); ?>" id="pendidikan" value="<?php echo e($penduduk->pendidikan); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('pendidikan')); ?>

              </div>
            </div>

            <div class="form-group">
              <label for="pekerjaan">Pekerjaan</label>
              <input type="text" name="pekerjaan" class="form-control <?php echo e($errors->first('pekerjaan') ? "is-invalid": ""); ?> " id="pekerjaan" value="<?php echo e($penduduk->pekerjaan); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('pekerjaan')); ?>

              </div>
            </div>
            <div class="form-group">
              <label for="dusun">Dusun</label>
              <input type="text" name="dusun" class="form-control <?php echo e($errors->first('dusun') ? "is-invalid": ""); ?> " id="dusun" value="<?php echo e($penduduk->dusun); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('dusun')); ?>

              </div>
            </div>
            <div class="form-group">
              <label for="rt">Rt</label>
              <input type="text" name="rt" class="form-control  <?php echo e($errors->first('rt') ? "is-invalid": ""); ?>" id="rt" value="<?php echo e($penduduk->rt); ?>">
              <div class="invalid-feedback">
                <?php echo e($errors->first('rt')); ?>

              </div>
            </div>

            <div class="form-group">
                <label for="rw">Rw</label>
                <input type="text" name="rw" class="form-control  <?php echo e($errors->first('rw') ? "is-invalid": ""); ?>" id="rw" value="<?php echo e($penduduk->rw); ?>">
                <div class="invalid-feedback">
                  <?php echo e($errors->first('rw')); ?>

                </div>
              </div>

              <div class="form-group">
                <label for="desa">Desa</label>
                <input type="text" name="desa" class="form-control  <?php echo e($errors->first('desa') ? "is-invalid": ""); ?>" id="desa" value="<?php echo e($penduduk->desa); ?>">
                <div class="invalid-feedback">
                  <?php echo e($errors->first('desa')); ?>

                </div>
              </div>

        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('adminlte/plugins/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adminlte/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script>
    $('#reservationdate').datetimepicker({
        format: 'L',
        format: 'DD-MM-YYYY',
    });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/penduduk/edit.blade.php ENDPATH**/ ?>