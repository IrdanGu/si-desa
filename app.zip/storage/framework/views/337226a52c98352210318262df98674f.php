<?php $__env->startSection('title'); ?>
    Main Gallery
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="maingalery" class="gallery">
    <div class="container">
        <h3 class="orange-text">Gallery</h3>
        <div class="gallery-container">
            <?php $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galerys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="gallery-item">
                    <a href="<?php echo e(asset('storage/' . $galerys->gambar)); ?>" target="_blank">
                    <img src="<?php echo e(asset('storage/' . $galerys->gambar)); ?>" class="gallery-image" alt="Gallery Image">

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('constra_template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/frontend/main_galery.blade.php ENDPATH**/ ?>