<?php $__env->startSection('title'); ?>
    Berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-10 mx-auto">
<form role="form" action="<?php echo e(route('beritastore')); ?>" method="POST" enctype="multipart/form-data">
        <div class="card-body">
            <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="judul">Judul</label>
                    <input type="text" name="judul" class="form-control <?php echo e($errors->first('judul') ? "is-invalid": ""); ?>" id="judul" placeholder="judul" value="<?php echo e(old('judul')); ?>">
                    <div class="invalid-feedback">
                      <?php echo e($errors->first('judul')); ?>

                    </div>
                  </div>
                <div class="form-group">
                    <label for="judul">Content</label>
                    <textarea class="textarea <?php echo e($errors->first('content') ? "is-invalid": ""); ?>" name="content" placeholder="Content" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e(old('content')); ?></textarea>
                    <div class="invalid-feedback">
                      <?php echo e($errors->first('content')); ?>

                    </div>
                </div>
                <div class="form-group">
                    <label for="exampleInputFile">Gambar</label>
                        <input type="file" class="form-control <?php echo e($errors->first('gambar') ? "is-invalid": ""); ?>" id="exampleInputFile" name="gambar" value="<?php echo e(old('gambar')); ?>">
                        <div class="invalid-feedback">
                          <?php echo e($errors->first('gambar')); ?>

                        </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/summernote/summernote-bs4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
<script>
  $(function () {
    $('.textarea').summernote()
  })
</script>
<script type="text/javascript">
    $(document).ready(function () {
      bsCustomFileInput.init();
    });
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/berita/create.blade.php ENDPATH**/ ?>