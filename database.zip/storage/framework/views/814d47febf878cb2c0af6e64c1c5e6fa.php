<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
            <a class="nav-link" href="#" id="notificationDropdown" data-toggle="dropdown">
                <i class="far fa-bell"></i>
                <?php if($surat_ktm + $surat_ku > 0): ?>
                    <span id="notification-count" class="badge badge-warning navbar-badge"><?php echo e($surat_ktm + $surat_ku); ?></span>
                <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-item dropdown-header">Notifications</span>
                <div class="dropdown-divider"></div>
                <?php if($notifications->count() > 0): ?>
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($notification instanceof App\Models\Surat): ?>
                    <a href="<?php echo e(route('suratindex')); ?>" class="dropdown-item notification-item" data-id="<?php echo e($notification->id); ?>">
                        <i class="fas fa-envelope mr-2"></i> <?php echo e($notification->nama); ?>

                        <span class="float-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                    </a>
                <?php elseif($notification instanceof App\Models\Surat_KeteranganUsaha): ?>
                    <a href="<?php echo e(route('surat_keteranganusahaindex')); ?>" class="dropdown-item notification-item" data-id="<?php echo e($notification->id); ?>">
                        <i class="fas fa-envelope mr-2"></i> <?php echo e($notification->nama); ?>

                        <span class="float-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>

                    </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
                    <span class="dropdown-item">No new messages</span>
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <a href="" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
        </li>

        <li class="nav-item d-none d-sm-inline-block">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</button>
            </form>
        </li>

        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                <i class="fas fa-th-large"></i>
            </a>
        </li>
    </ul>
</nav>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    function updateNotificationCount() {
        $.ajax({
            url: '<?php echo e(route("navbar.data")); ?>',
            method: 'GET',
            success: function(response) {
                $('#notification-count').text(response.surat);
            },
            error: function() {
                console.error('Failed to fetch notification count.');
            }
        });
    }

    // Update notification count on page load
    updateNotificationCount();

    // Optionally, update periodically (e.g., every 5 minutes)
    setInterval(updateNotificationCount, 300000); // 5 minutes in milliseconds

    // Mark notifications as read when clicked
    $(document).on('click', '.notification-item', function(event) {
        // event.preventDefault();
        // var notificationId = $(this).data('id');
        // var notificationItem = $(this);

        $.ajax({
            url: '<?php echo e(route("notification.read")); ?>',
            method: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: notificationId
            },
            success: function() {
                var count = parseInt($('#notification-count').text()) - 1;
                if (count <= 0) {
                    $('#notification-count').remove();
                } else {
                    $('#notification-count').text(count);
                }
                // Redirect to suratindex after marking as read
                window.location.href = notificationItem.attr('href');
            },
            error: function() {
                console.error('Failed to mark notification as read.');
            }
        });
    });
});


</script>
<?php /**PATH C:\laragon\www\sidesass\resources\views/adminlte/partial/navbar.blade.php ENDPATH**/ ?>