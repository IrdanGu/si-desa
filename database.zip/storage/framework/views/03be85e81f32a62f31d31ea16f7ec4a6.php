<?php $__env->startSection('title'); ?>
    Data Berita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Struktur desa</h3>
    </div>
        <div class="card-header">
      <form action="">
        <div class="row">
              <div class="col-md-7">
                <input value="<?php echo e(Request::get('keyword')); ?>" name="keyword" class="form-control"type="text" placeholder="Masukan Judul untuk pencarian.....">
              </div>
              <button type="submit" class="btn btn-primary"> <i class="fas fa-search" ></i> Cari </button>
        </div>
      </form>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table class="table table-bordered table-hover ">
        <thead class="table-secondary">
          <tr>
            <th>No</th>
            <th>Gambar</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $aparatur_desas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $aparatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($no+1); ?></td>
              <td><img src="<?php echo e(asset('storage/' . $aparatur->gambar_struktur)); ?>" width="48px"></td>
              <td>
              <a  href="<?php echo e(route('aparaturedit', $aparatur->id)); ?>"><button style="padding-right:26px" type="submit"  class="btn btn-info"><i class="fas fa-edit"></i> Edit</button> </a>
                <form style="margin-top:2px;" action="<?php echo e(route('aparaturdelete',$aparatur->id)); ?>" method="post" >
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button onclick="return confirm('Yakin Hapus Data Ini?')" class="btn  btn-danger" type="submit "><i class="fas fa-trash"></i> Hapus</button>
                </form>
              </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

      </table>
    </div>
    <!-- /.card-body -->
    <div class="card-footer clearfix">
      <ul class="pagination pagination-sm m-0 float-right">

      </ul>
    </div>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/aparatur/index.blade.php ENDPATH**/ ?>