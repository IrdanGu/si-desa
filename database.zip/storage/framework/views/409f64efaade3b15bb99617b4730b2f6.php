<?php $__env->startSection('title'); ?>
    Surat Keterangan Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title"> Surat Keterangan Usaha</h3>
    </div>
    <div class="card-header">
        <a class="btn btn-primary" href="<?php echo e(route('suratcreate')); ?>">Buat Surat</a>
    </div>
    <div class="card-header">
      <form action="">
        <div class="row">
              <div class="col-md-6">
                <input value="<?php echo e(Request::get('keyword')); ?>" name="keyword" class="form-control"type="text" placeholder="Masukan NIK untuk pencarian.....">
              </div>
              <div class="col-md-4 ml-4 ">
                <input <?php echo e(Request::get('status') == 'Approve' ? 'checked' : ''); ?> class="form-check-input mt-3" type="radio" name="status" value="Approve" id="Approve">
                  <label class="ml-1 " for="Approve">Approve</label>
                <input <?php echo e(Request::get('status') == 'Cancel' ? 'checked' : ''); ?> class="form-check-input ml-4 mt-3 " type="radio" name="status" value="Cancel" id="Cancel">
                  <label style="margin-top:10px" class="ml-5 " for="Cancel">Cancel</label>
                <button  type="submit" class="btn btn-primary ml-4 mb-1 "> <i class="fas fa-search"></i> Cari</button>
              </div>
        </div>
      </form>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
      <table id="table-product" class="table table-bordered table-hover ">
        <thead class="table-secondary">
          <tr>
            <th>NIK</th>
            <th>KK</th>
            <th>Nama</th>
            <th>Jenis Surat</th>
            <th>Foto KTP</th>
            <th>Foto KK</th>
            <th>Permohonan</th>
            <th>No Handphone </th>
            <th>Status</th>
            <th>Pembuat surat</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php
            $bulanRomawi = array("", "I","II","III", "IV", "V","VI","VII","VIII","IX","X", "XI","XII")
        ?>
        <?php $__currentLoopData = $surat__KeteranganUsaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_keteranganusahas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
          
          <td><?php echo e($surat_keteranganusahas->nik); ?></td>
          <td><?php echo e($surat_keteranganusahas->no_kk); ?></td>
          <td><?php echo e($surat_keteranganusahas->nama); ?></td>
          <td><?php echo e($surat_keteranganusahas->pilihsurat); ?></td>
          <td><a href="#" data-toggle="modal" data-target="#ktpModal<?php echo e($surat_keteranganusahas->id); ?>"><img src="<?php echo e(asset('storage/' . $surat_keteranganusahas->fotoktp)); ?>" width="48px"></a></td>
          <td><a href="#" data-toggle="modal" data-target="#kkModal<?php echo e($surat_keteranganusahas->id); ?>"><img src="<?php echo e(asset('storage/' . $surat_keteranganusahas->fotokk)); ?>" width="48px"></a></td>
          <td><?php echo e($surat_keteranganusahas->permohonan); ?></td>
          



          <td><?php echo e($surat_keteranganusahas->no_hp); ?></td>
          <td> <?php if($surat_keteranganusahas->status == "Approve"): ?>
            <span class="badge badge-success"><?php echo e($surat_keteranganusahas->status); ?>

            <?php else: ?>
            <span class="badge bg-danger text-white"><?php echo e($surat_keteranganusahas->status); ?></span>
            </span>
            <?php endif; ?></td>
          <td><?php if($surat_keteranganusahas->status == "Approve"): ?>
              <?php echo e($surat_keteranganusahas->user->level); ?>

              <?php else: ?>
              <?php echo e($surat_keteranganusahas->nama); ?>

              <?php endif; ?>
          </td>
          <td>
          <?php if($surat_keteranganusahas->status == "Approve"): ?>
          <a  href="<?php echo e(route('suratedit',$surat_keteranganusahas->id)); ?>"><button type="submit"  class="btn btn-info"><i class="fas fa-edit"></i> Edit</button> </a>
          <form  action="<?php echo e(route('suratdelete',$surat_keteranganusahas->id)); ?>" method="post" class="form-check-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button onclick="return confirm('Yakin Hapus Data Ini?')" class="btn  btn-danger" type="submit "><i class="fas fa-trash"></i> Hapus</button>
          </form>
          <?php endif; ?>

          <?php if($surat_keteranganusahas->status == "Cancel"): ?>
          <form  action="<?php echo e(route(('suratupdateSKU'),$surat_keteranganusahas->id)); ?>" method="POST" class="form-check-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <button onclick="return confirm('Yakin Approve Surat Ini?')" class="btn btn-primary" type="submit "><i class="fas fa-cancel"></i> Approve</button>
          </form>
          <?php endif; ?>
          </td>
          </tr>

          <!-- Modal for KTP -->
          <div class="modal fade" id="ktpModal<?php echo e($surat_keteranganusahas->id); ?>" tabindex="-1" role="dialog" aria-labelledby="ktpModalLabel<?php echo e($surat_keteranganusahas->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="ktpModalLabel<?php echo e($surat_keteranganusahas->id); ?>">Foto KTP</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <img src="<?php echo e(asset('storage/' . $surat_keteranganusahas->fotoktp)); ?>" class="img-fluid">
                </div>
              </div>
            </div>
          </div>

          <!-- Modal for KK -->
          <div class="modal fade" id="kkModal<?php echo e($surat_keteranganusahas->id); ?>" tabindex="-1" role="dialog" aria-labelledby="kkModalLabel<?php echo e($surat_keteranganusahas->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="kkModalLabel<?php echo e($surat_keteranganusahas->id); ?>">Foto KK</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <img src="<?php echo e(asset('storage/' . $surat_keteranganusahas->foto_kk)); ?>" class="img-fluid">
                </div>
              </div>
            </div>
          </div>

          <!-- Modal -->


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="d-flex justify-content-center">
        <?php echo e($surat__KeteranganUsaha->links('pagination::bootstrap-4')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/surat_KeteranganUsaha/index.blade.php ENDPATH**/ ?>