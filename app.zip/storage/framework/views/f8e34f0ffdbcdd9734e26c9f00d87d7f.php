<?php $__env->startSection('title'); ?>
    User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-10 mx-auto">
<form role="form" action="<?php echo e(route('userstore')); ?>" method="POST">
      <div class="card-body">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Nama</label>
            <input type="text" name="name" class="form-control <?php echo e($errors->first('name') ? "is-invalid": ""); ?>" id="name" placeholder="Nama" value="<?php echo e(old('name')); ?>">
            <div class="invalid-feedback">
              <?php echo e($errors->first('name')); ?>

            </div>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" class="form-control <?php echo e($errors->first('email') ? "is-invalid": ""); ?>" id="email" placeholder="Nama" value="<?php echo e(old('email')); ?>">
            <div class="invalid-feedback">
              <?php echo e($errors->first('email')); ?>

            </div>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control <?php echo e($errors->first('password') ? "is-invalid": ""); ?>" id="password" placeholder="Password" value="<?php echo e(old('password')); ?>">
            <div class="invalid-feedback">
              <?php echo e($errors->first('password')); ?>

            </div>
          </div>

          <label for="level">Level</label>
          <div class="form-group">
            <div class="form-check form-check-inline">
                <input id="level" class="form-check-input" type="radio" name="level" value="admin" <?php echo e((old('level') == 'admin') ? 'checked' : ''); ?>>
                <label class="form-check-label">Admin</label>
            </div>
            <div class="form-check form-check-inline">
                <input id="level" class="form-check-input" type="radio" name="level" value="karangtaruna"  <?php echo e((old('level') == 'karangtaruna') ? 'checked' : ''); ?>>
                <label class="form-check-label">Karangtaruna</label>
            </div>

                <div class="invalid-feedback">
                 &emsp;<?php echo e($errors->first('level')); ?>

                </div>
              </div>
          </div>

        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/user/create.blade.php ENDPATH**/ ?>