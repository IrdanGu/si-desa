<?php $__env->startSection('title'); ?>
    main agenda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="mainberita" class="berita">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
            <H3 class="orange-text">Agenda</H3>
            <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-4">
                <div class="post-metamain">
                    <h4 class="card-title"><?php echo e($agendas->judul); ?></h4>
                    <div class="post-date"></div>
                    <span class="post-author">
                       <i class="fa fa-user"></i><a href="#"><?php echo e($agendas->user->level); ?></a>
                    </span>

                    <span class="post-meta-date"><i class="fa fa-calendar mr-2"></i><?php echo e(\Carbon\Carbon::parse($agendas['created_at'])->isoFormat('D MMMM, Y')); ?></span>
                 </div>
                <div class="card-body">

                    <article>
                        <p>tanggal :<?php echo e($agendas->tanggal); ?>, jam :<?php echo e($agendas->jam); ?>, acara :<?php echo e($agendas->acara); ?>, tempat :<?php echo e($agendas->tempat); ?>, <?php echo e(Str::limit(strip_tags(html_entity_decode($agendas->content)), 30)); ?>,<a href="<?php echo e(route('agenda_detail',$agendas->judul)); ?>" class="orange-text">...selengkapnya</a> </p>
                    </article>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


          <!-- Sidebar start -->
          <div class="col-md-4">
            <br>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                </button>
            </form>
            <br>
            <h4 class="orange-text">Agenda <span class="font-weight-bold">Kegiatan</span></h4>
            <ul class="list-group">
                <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agendas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex align-items-start border-0 p-2 mb-3 ">
                        <div class="date-box text-center mr-3 p-2" style="background-color: orange; color: white;">
                            <span class="date d-block font-weight-bold"><?php echo e(\Carbon\Carbon::parse($agendas->tanggal)->format('M d')); ?></span>
                            <span class="year"><?php echo e(\Carbon\Carbon::parse($agendas->tanggal)->format('Y')); ?></span>
                        </div>

                        <div class="agenda-text">
                            <a href="<?php echo e(route('agenda_detail', $agendas->judul)); ?>" class="font-weight-bold text-orange"><?php echo e($agendas->judul); ?></a>
                            <p class="mb-0 text-dark">Lokasi: <?php echo e($agendas->tempat); ?></p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

              <!-- Galeri Foto -->
              <div class="iklan-galeri">
                <h4 class="orange-text-galery">
                    <i class="fas fa-camera icon"></i> <!-- Ganti ikon sesuai kebutuhan -->
                    Galeri Foto
                </h4>

              <div class="gallery-main">
                  <?php $__currentLoopData = $galery->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galerys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="gallery-item-main">
                          <img src="<?php echo e(asset('storage/' . $galerys->gambar)); ?>" alt="Gallery Image">
                      </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
          </div>
          </div>
          <!-- Sidebar end -->
            </div>
        </div>
    </div>
    <br></br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('constra_template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/frontend/main_agenda.blade.php ENDPATH**/ ?>