<?php $__env->startSection('title'); ?>
    Surat Keterangan Usaha
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-10 mx-auto">
    <form role="form" action="<?php echo e(route('suratupdate', $surat->id)); ?>" method="POST">
        <div class="card-body">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label for="pilihsurat">Pilih Surat</label>
                <select class="form-control" id="pilihsurat" name="pilihsurat" required>
                    <option value="Surat Keterangan Tidak Mampu" <?php echo e(old('pilihsurat', $surat->pilihsurat) == 'Surat Keterangan Tidak Mampu' ? 'selected' : ''); ?>>Surat Keterangan Tidak Mampu</option>
                    <option value="Surat Keterangan Usaha" <?php echo e(old('pilihsurat', $surat->pilihsurat) == 'Surat Keterangan Usaha' ? 'selected' : ''); ?>>Surat Keterangan Usaha</option>
                </select>
            </div>

            <div class="form-group">
                <label for="no_hp">No Handphone</label>
                <input type="text" name="no_hp" class="form-control <?php echo e($errors->first('no_hp') ? "is-invalid": ""); ?> " id="no_hp" value="<?php echo e($surat->no_hp); ?>">
                <div class="invalid-feedback">
                  <?php echo e($errors->first('no_hp')); ?>

                </div>
              </div>


            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sidesass\resources\views/surat/edit.blade.php ENDPATH**/ ?>